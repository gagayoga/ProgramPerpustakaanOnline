﻿Imports System.Data.SqlClient
Imports System.Reflection.Emit
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel

Public Class FormDataBuku
    Sub Kondisiawal()
        kode.Text = ""
        kode.MaxLength = 6
        judul.Text = ""
        penulis.Text = ""
        penerbit.Text = ""
        gambar.Text = ""
        gambar.Enabled = False
        stok.Text = ""
        Button1.Text = "INPUT"
        Button2.Text = "EDIT"
        Button3.Text = "DELETE"
        Button4.Text = "TUTUP"
        PictureBox1.ImageLocation = gambar.Text
        'Call KodeOtomatis()
        'Call edit()
        Munculkandata()
    End Sub

    'Sub KodeOtomatis()
    '    Call Kondisiawal()
    '    cmd = New SqlCommand("select * from buku where kode_buku in(select max(kode_buku) from buku)", conn)
    '    Dim urutankode As String
    '    Dim hitung As Long
    '    dr = cmd.ExecuteReader
    '    dr.Read()
    '    If Not dr.HasRows Then
    '        kode.Text = "BOOK" + "001"
    '    Else
    '        hitung = Microsoft.VisualBasic.Right(dr.GetString(0), 3) + 1
    '        urutankode = "BOOK" + Microsoft.VisualBasic.Right("000" & hitung, 9)
    '    End If
    '    kode.Text = urutankode
    'End Sub

    Sub Munculkandata()
        Call Koneksi()
        da = New SqlDataAdapter("SELECT * FROM buku", conn)
        ds = New DataSet
        da.Fill(ds, "buku")
        DataGridView1.DataSource = (ds.Tables("buku"))
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    'Sub edit()
    '    DataGridView1.Columns(0).HeaderText = ("Kode buku")
    '    DataGridView1.Columns(1).HeaderText = ("Judul")
    '    DataGridView1.Columns(2).HeaderText = ("Penulis")
    '    DataGridView1.Columns(3).HeaderText = ("Penerbit")
    '    DataGridView1.Columns(4).HeaderText = ("Foto")
    '    DataGridView1.Columns(5).HeaderText = ("Stok")
    'End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        bukafile.Filter = "*.jpg|"
        bukafile.ShowDialog()
        gambar.Text = bukafile.FileName
        PictureBox1.ImageLocation = gambar.Text
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

    Private Sub FormDataBuku_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Kondisiawal()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If kode.Text = "" Or judul.Text = "" Or penulis.Text = "" Or penerbit.Text = "" Or gambar.Text = "" Or stok.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            Call Koneksi()
            cmd = New SqlCommand("SELECT * FROM buku where kode_buku='" & kode.Text & "'", conn)
            dr = cmd.ExecuteReader()
            dr.Read()
            If dr.HasRows Then
                MsgBox("Data dengan kode tersebut sudah ada,silakan register dengan kode yang lain", MessageBoxIcon.Information)
                kode.Focus()
            Else
                'ini proses mencocokan data dengan inputan user
                Call Koneksi()
                Dim InputData = "INSERT INTO buku values('" & kode.Text & "','" & judul.Text & "','" & penulis.Text & "','" & penerbit.Text & "','" & gambar.Text & "','" & stok.Text & "')"
                cmd = New SqlCommand(InputData, conn)
                cmd.ExecuteReader()
                MsgBox("Data berhasil di input", MessageBoxIcon.Information)
                Call Kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If kode.Text = "" Or judul.Text = "" Or penulis.Text = "" Or penerbit.Text = "" Or gambar.Text = "" Or stok.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            'ini proses mencocokan data dengan inputan user
            Call Koneksi()
            Dim EditData = "UPDATE buku set judul='" & judul.Text & "', penulis='" & penulis.Text & "',penerbit='" & penerbit.Text & "',foto='" & gambar.Text & "',stok='" & stok.Text & "' where kode_buku='" & kode.Text & "'"
            cmd = New SqlCommand(EditData, conn)
            cmd.ExecuteReader()
            MsgBox("Data berhasil di edit", MessageBoxIcon.Information)
            Call Kondisiawal()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If kode.Text = "" Or judul.Text = "" Or penulis.Text = "" Or penerbit.Text = "" Or gambar.Text = "" Or stok.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            If MessageBox.Show("Apakah anda yakin mau menghapus data", "Pertanyaan", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Dim HapusData = "Delete from buku where kode_buku='" & kode.Text & "'"
                cmd = New SqlCommand(HapusData, conn)
                cmd.ExecuteReader()
                MsgBox("Data berhasil di edit", MessageBoxIcon.Information)
                Call Kondisiawal()
            Else
                Call Kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        On Error Resume Next
        kode.Text = DataGridView1.Item(0, i).Value
        judul.Text = DataGridView1.Item(1, i).Value
        penulis.Text = DataGridView1.Item(2, i).Value
        penerbit.Text = DataGridView1.Item(3, i).Value
        gambar.Text = DataGridView1.Item(4, i).Value
        stok.Text = DataGridView1.Item(5, i).Value
        PictureBox1.ImageLocation = gambar.Text
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

    Private Sub stok_TextChanged(sender As Object, e As EventArgs) Handles stok.TextChanged

    End Sub

    Private Sub stok_KeyPress(sender As Object, e As KeyPressEventArgs) Handles stok.KeyPress
        If Char.IsNumber(e.KeyChar) OrElse e.KeyChar = vbBack Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
End Class