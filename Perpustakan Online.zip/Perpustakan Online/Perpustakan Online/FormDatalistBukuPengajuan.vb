﻿Imports System.Data.SqlClient

Public Class FormDatalistBukuPengajuan
    Sub jumlahdata()
        Dim jmlh
        jmlh = DataGridView1.RowCount
        jumlah.Text = jmlh
    End Sub
    Sub Munculkandata()
        Call Koneksi()
        da = New SqlDataAdapter("SELECT * FROM peminjaman ", conn)
        ds = New DataSet
        da.Fill(ds, "peminjaman")
        DataGridView1.DataSource = (ds.Tables("peminjaman"))
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    Private Sub FormDatalistBukuPengajuan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Munculkandata()
        Call jumlahdata()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        On Error Resume Next
        id.Text = DataGridView1.Item(0, i).Value
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        FormValidasi.ShowDialog()
    End Sub
End Class