﻿Imports System.Data.SqlClient

Public Class FormEditAnggota
    Sub Kondisiawal()
        'Ini deklarasi Untuk nilai awalan inputan
        id.Focus()
        id.Text = FormHalamanIUtama.SLabelisi2.Text
        id.MaxLength = 6
        telepon.MaxLength = 13
        username.Text = ""
        nama.Text = ""
        telepon.Text = ""
        password.Text = ""
        password.ForeColor = Color.Black
        password.PasswordChar = "X"
        'peringatan.Text = ""
        'peringatan.Enabled = False
    End Sub

    Private Sub FormEditAnggota_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Kondisiawal()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If id.Text = "" Or nama.Text = "" Or username.Text = "" Or password.Text = "" Or telepon.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            'ini proses mencocokan data dengan inputan user
            Call Koneksi()
            Dim EditData = "UPDATE anggota2 set nama='" & nama.Text & "', username='" & username.Text & "',pasword='" & password.Text & "', telp='" & telepon.Text & "' where id_anggota='" & id.Text & "'"
            cmd = New SqlCommand(EditData, conn)
            cmd.ExecuteReader()
            MsgBox("Data berhasil di ubah", MessageBoxIcon.Information)
            Call Kondisiawal()
        End If

    End Sub

    Private Sub id_TextChanged(sender As Object, e As EventArgs) Handles id.TextChanged

    End Sub

    Private Sub id_KeyPress(sender As Object, e As KeyPressEventArgs) Handles id.KeyPress
        If e.KeyChar = Chr(13) Then
            Call Koneksi()
            cmd = New SqlCommand("select * from anggota2 where id_anggota='" & id.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                nama.Text = dr.Item("nama")
                username.Text = dr.Item("username")
                password.Text = dr.Item("pasword")
                telepon.Text = dr.Item("telp")
            Else
                MsgBox("Data tidak ditemukan")
            End If
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            password.PasswordChar = ""
        Else
            password.PasswordChar = "X"
        End If
    End Sub
End Class