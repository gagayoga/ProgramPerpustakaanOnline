﻿Imports System.Data.SqlClient

Public Class FormLaporanDataPeminjaman
    Sub jumlahdata()
        Dim jmlh
        jmlh = DataGridView1.CurrentRow
        jumlah.Text = jmlh
    End Sub
    Sub Munculkandata()
        Call Koneksi()


        da = New SqlDataAdapter("SELECT peminjaman.id_peminjaman,buku.judul,anggota2.nama,petugas.nama_petugas,peminjaman.tgl_pinjam,peminjaman.tgl_kembali,peminjaman.status  FROM peminjaman,buku,anggota2,petugas where buku.kode_buku=peminjaman.kode_buku AND anggota2.id_anggota=peminjaman.id_anggota AND petugas.id_petugas=peminjaman.id_petugas", conn)
        ds = New DataSet
        da.Fill(ds, "peminjaman")
        DataGridView1.DataSource = (ds.Tables("peminjaman"))
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    Sub ediit()
        DataGridView1.Columns(0).HeaderText = "Id Peminjaman"
        DataGridView1.Columns(1).HeaderText = "Judul Buku"
        DataGridView1.Columns(2).HeaderText = "Nama Anggota"
        DataGridView1.Columns(3).HeaderText = "Nama Petugas"
        DataGridView1.Columns(4).HeaderText = "Tanggal Pinjam"
        DataGridView1.Columns(5).HeaderText = "Tanggal Kembali"
        DataGridView1.Columns(6).HeaderText = "Status"
    End Sub
    Private Sub FormLaporanDataPeminjaman_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call jumlahdata()
        Call Munculkandata()
        Call ediit()
    End Sub
End Class