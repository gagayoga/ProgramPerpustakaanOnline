﻿Imports System.Data.SqlClient

Public Class FormLaporanDataBuku
    Sub jumlahdata()
        Dim jmlh
        jmlh = DataGridView1.CurrentRow
        jumlah.Text = jmlh
    End Sub
    Sub Munculkandata()
        Call Koneksi()
        da = New SqlDataAdapter("SELECT * FROM buku", conn)
        ds = New DataSet
        da.Fill(ds, "buku")
        DataGridView1.DataSource = (ds.Tables("buku"))
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    Sub ediit()
        DataGridView1.Columns(0).HeaderText = "Kode Buku"
        DataGridView1.Columns(1).HeaderText = "Judul Buku"

        DataGridView1.Columns(2).HeaderText = "Penulis Buku"
        DataGridView1.Columns(3).HeaderText = "Penerbit Buku"
        DataGridView1.Columns(4).HeaderText = "Gambar Buku"
        DataGridView1.Columns(5).HeaderText = "Stok Buku"
    End Sub
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub FormLaporanDataBuku_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call jumlahdata()
        Call Munculkandata()
        Call ediit()
    End Sub
End Class