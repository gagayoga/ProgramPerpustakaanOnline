﻿Imports System.Data.SqlClient

Public Class FormRegisterAnggota
    Sub Kondisiawal()
        'Ini deklarasi Untuk nilai awalan inputan
        id.Focus()
        id.MaxLength = 6
        telepon.MaxLength = 13
        username.Text = ""
        nama.Text = ""
        telepon.Text = ""
        password.Text = ""
        password.ForeColor = Color.Black
        password.PasswordChar = "X"
        'peringatan.Text = ""
        'peringatan.Enabled = False
    End Sub
    Private Sub FormRegisterAnggota_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Kondisiawal()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            password.PasswordChar = ""
        Else
            password.PasswordChar = "X"
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'ini validasi jika ada inputan yang kosong maka akan muncul pop up
        If id.Text = "" Or nama.Text = "" Or username.Text = "" Or password.Text = "" Or telepon.Text = "" Then
            MsgBox("Masukan semua data terlebih dahulu", MessageBoxIcon.Warning)
            'ini validasi jika password kurang dari 8 maka teks akan berubah warna menjadi merah
            'ElseIf password.TextLength < 8 Then
            '    password.ForeColor = Color.Red
            '    peringatan.Text = "password minimal 8,kurang dari 8 tidak bisa masuk aplikasi"
        Else
            Call Koneksi()
            cmd = New SqlCommand("SELECT * FROM anggota2 where id_anggota='" & id.Text & "'", conn)
            dr = cmd.ExecuteReader()
            dr.Read()
            If dr.HasRows Then
                MsgBox("Data dengan id tersebut sudah ada,silakan register dengan id yang lain", MessageBoxIcon.Information)
                id.Focus()
            Else
                'ini proses mencocokan data dengan inputan user
                Call Koneksi()
                Dim InputData = "INSERT INTO anggota2 values('" & id.Text & "','" & nama.Text & "','" & username.Text & "','" & password.Text & "','" & telepon.Text & "')"
                cmd = New SqlCommand(InputData, conn)
                cmd.ExecuteReader()
                MsgBox("Register berhasil,silakan login lagi", MessageBoxIcon.Information)
                Call Kondisiawal()
                Me.Close()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub id_TextChanged(sender As Object, e As EventArgs) Handles id.TextChanged

    End Sub

    Private Sub id_KeyPress(sender As Object, e As KeyPressEventArgs) Handles id.KeyPress
        If Char.IsNumber(e.KeyChar) OrElse e.KeyChar = vbBack Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub telepon_TextChanged(sender As Object, e As EventArgs) Handles telepon.TextChanged

    End Sub
End Class