﻿Imports System.Data.SqlClient

Public Class FormLoginPetugas
    Sub Kondisiawal()
        'Ini deklarasi Untuk nilai awalan inputan
        username.Text = "dzawinnur"
        password.Text = "dzawin"
        password.ForeColor = Color.Black
        password.PasswordChar = "X"
        peringatan.Text = ""
        peringatan.Enabled = False
    End Sub
    Private Sub FormLoginPetugas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Kondisiawal()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            password.PasswordChar = ""
        Else
            password.PasswordChar = "X"
        End If
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        FormRegisterPetugas.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'ini validasi jika ada inputan yang kosong maka akan muncul pop up
        If username.Text = "" Or password.Text = "" Then
            MsgBox("Masukan semua data terlebih dahulu", MessageBoxIcon.Warning)
            'ini validasi jika password kurang dari 8 maka teks akan berubah warna menjadi merah
            'ElseIf password.TextLength < 8 Then
            '    password.ForeColor = Color.Red
            '    peringatan.Text = "password minimal 8,kurang dari 8 tidak bisa masuk aplikasi"
        Else
            'ini proses mencocokan data dengan inputan user
            Call Koneksi()
            cmd = New SqlCommand("select * from petugas where username='" & username.Text & "' and pasword='" & password.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                MsgBox("Login Berhasil", MessageBoxIcon.Information)
                Me.Hide()
                'ini untuk mengisi status strip di halaman utama
                FormHalamanIUtama.SLabelisi1.Text = dr.Item("username")
                FormHalamanIUtama.SLabel2.Text = "Id Petugas : "
                FormHalamanIUtama.SLabelisi2.Text = dr.Item("id_petugas")
                FormHalamanIUtama.SLabelisi3.Text = dr.Item("level")
                'ini validasi jika yang login admin maka menu yang dapat di akses sebagai berikut
                If FormHalamanIUtama.SLabelisi3.Text = "Admin" Then
                    FormHalamanIUtama.DataPengajuanBukuToolStripMenuItem.Visible = False
                    FormHalamanIUtama.EditProfilAnggotaToolStripMenuItem.Visible = False
                    'ini validasi jika yang login petugas maka menu yang dapat di akses sebagai berikut
                ElseIf FormHalamanIUtama.SLabelisi3.Text = "Petugas" Then
                    FormHalamanIUtama.MasterToolStripMenuItem.Visible = False
                    FormHalamanIUtama.DataPengajuanBukuToolStripMenuItem.Visible = False
                    FormHalamanIUtama.EditProfilAnggotaToolStripMenuItem.Visible = False
                    FormHalamanIUtama.LaporanToolStripMenuItem.Visible = False
                Else
                    'ini validasi jika yang login tidak ada nama levelnya maka akun berbahaya
                    FormHalamanIUtama.MasterToolStripMenuItem.Visible = False
                    FormHalamanIUtama.TransaksiToolStripMenuItem.Visible = False
                    FormHalamanIUtama.TransaksiToolStripMenuItem.Visible = False
                    FormHalamanIUtama.UtilityToolStripMenuItem.Visible = False
                    MsgBox("Akun anda bermasalah bahaya", MessageBoxIcon.Warning)

                End If
                'ini validasi hak akses aplikasi 
                'FormHalamanIUtama.DaftarListPengajuanBukuToolStripMenuItem.Visible = False
                'FormHalamanIUtama.TransaksiToolStripMenuItem.Visible = False
                'FormHalamanIUtama.LaporanToolStripMenuItem.Visible = False
                'FormHalamanIUtama.EditProfilAnggotaToolStripMenuItem.Visible = False
                FormHalamanIUtama.ShowDialog()
            Else
                MsgBox("Data tidak ditemukan,silakan anda login lagi dengan data yang benar", MessageBoxIcon.Information)
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Me.Close()
    End Sub
End Class