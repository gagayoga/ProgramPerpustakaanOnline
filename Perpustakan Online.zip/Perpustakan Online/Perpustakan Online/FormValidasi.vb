﻿Imports System.Data.SqlClient
Imports System.Reflection.Emit
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel

Public Class FormValidasi
    Sub kondisiawal()
        id.Text = FormDatalistBukuPengajuan.id.Text
        pinjam.Enabled = False
        anggota.Enabled = False
        petugas.Enabled = False
        kembali.Enabled = False
        status.Items.Clear()
        status.Items.Add("Pengajuan")
        status.Items.Add("Proses")
        status.Items.Add("Selesai")
    End Sub
    Private Sub status_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub FormValidasi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call kondisiawal()
    End Sub

    Private Sub id_TextChanged(sender As Object, e As EventArgs) Handles id.TextChanged

    End Sub

    Private Sub id_KeyPress(sender As Object, e As KeyPressEventArgs) Handles id.KeyPress
        If e.KeyChar = Chr(13) Then
            Call Koneksi()
            cmd = New SqlCommand("select * from peminjaman where id_peminjaman='" & id.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                buku.Text = dr.Item("kode_buku")
                anggota.Text = dr.Item("id_anggota")
                petugas.Text = dr.Item("id_petugas")
                pinjam.Text = dr.Item("tgl_pinjam")
                kembali.Text = dr.Item("tgl_kembali")
                status.Text = dr.Item("status")
            Else
                MsgBox("Data tidak ditemukan")
            End If
        Else
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If id.Text = "" Or buku.Text = "" Or anggota.Text = "" Or petugas.Text = "" Or pinjam.Text = "" Or kembali.Text = "" Or status.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            'ini proses mencocokan data dengan inputan user
            Call Koneksi()
            Dim EditData = "UPDATE peminjaman set status='" & status.Text & "' where id_peminjaman='" & id.Text & "'"
            cmd = New SqlCommand(EditData, conn)
            cmd.ExecuteReader()
            MsgBox("Data berhasil di validasi", MessageBoxIcon.Information)
            Call kondisiawal()
        End If
    End Sub
End Class