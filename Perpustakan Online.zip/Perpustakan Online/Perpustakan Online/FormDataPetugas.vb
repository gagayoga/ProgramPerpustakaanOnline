﻿Imports System.Data.SqlClient

Public Class FormDataPetugas
    Sub Kondisiawal()
        'Ini deklarasi Untuk nilai awalan inputan
        id.Focus()
        id.Text = ""
        id.MaxLength = 6
        telepon.MaxLength = 13
        username.Text = ""
        nama.Text = ""
        telepon.Text = ""
        password.Text = ""
        level.Text = ""
        password.ForeColor = Color.Black
        password.PasswordChar = "X"
        level.Items.Clear()
        level.Items.Add("Admin")
        level.Items.Add("Petugas")
        Button1.Text = "INPUT"
        Button2.Text = "EDIT"
        Button3.Text = "DELETE"
        Button4.Text = "TUTUP"
        'peringatan.Text = ""
        'peringatan.Enabled = False
        Munculkandata()
        'Call KodeOtomatis()
        'Call edittampilan()
    End Sub
    Sub Munculkandata()
        Call Koneksi()
        da = New SqlDataAdapter("SELECT * FROM petugas", conn)
        ds = New DataSet
        da.Fill(ds, "petugas")
        DataGridView1.DataSource = (ds.Tables("petugas"))
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub
    Private Sub FormDataPetugas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Kondisiawal()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If id.Text = "" Or nama.Text = "" Or username.Text = "" Or password.Text = "" Or telepon.Text = "" Or level.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            Call Koneksi()
            cmd = New SqlCommand("SELECT * FROM petugas where id_petugas='" & id.Text & "'", conn)
            dr = cmd.ExecuteReader()
            dr.Read()
            If dr.HasRows Then
                MsgBox("Data dengan id tersebut sudah ada,silakan masukan id yang lain", MessageBoxIcon.Information)
                id.Focus()
            Else
                'ini proses mencocokan data dengan inputan user
                Call Koneksi()
                Dim InputData = "INSERT INTO petugas values('" & id.Text & "','" & nama.Text & "','" & username.Text & "','" & password.Text & "','" & telepon.Text & "','" & level.Text & "')"
                cmd = New SqlCommand(InputData, conn)
                cmd.ExecuteReader()
                MsgBox("Data berhasil di input", MessageBoxIcon.Information)
                Call Kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If id.Text = "" Or nama.Text = "" Or username.Text = "" Or password.Text = "" Or telepon.Text = "" Or level.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            'ini proses mencocokan data dengan inputan user
            Call Koneksi()
            Dim EditData = "UPDATE petugas set nama_petugas='" & nama.Text & "', username='" & username.Text & "', pasword='" & password.Text & "', telp='" & telepon.Text & "', level='" & level.Text & "' where id_petugas='" & id.Text & "'"
            cmd = New SqlCommand(EditData, conn)
            cmd.ExecuteReader()
            MsgBox("Data berhasil di edit", MessageBoxIcon.Information)
            Call Kondisiawal()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If id.Text = "" Or nama.Text = "" Or username.Text = "" Or password.Text = "" Or telepon.Text = "" Or level.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            If MessageBox.Show("Apakah anda yakin mau menghapus data", "Pertanyaan", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Dim HapusData = "Delete from petugas where id_petugas='" & id.Text & "'"
                cmd = New SqlCommand(HapusData, conn)
                cmd.ExecuteReader()
                MsgBox("Data berhasil di edit", MessageBoxIcon.Information)
                Call Kondisiawal()
            Else
                Call Kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        On Error Resume Next
        id.Text = DataGridView1.Item(0, i).Value
        nama.Text = DataGridView1.Item(1, i).Value
        username.Text = DataGridView1.Item(2, i).Value
        password.Text = DataGridView1.Item(3, i).Value
        telepon.Text = DataGridView1.Item(4, i).Value
        level.Text = DataGridView1.Item(5, i).Value
    End Sub

    Private Sub id_TextChanged(sender As Object, e As EventArgs) Handles id.TextChanged

    End Sub

    Private Sub id_KeyPress(sender As Object, e As KeyPressEventArgs) Handles id.KeyPress
        If Char.IsNumber(e.KeyChar) OrElse e.KeyChar = vbBack Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub telepon_TextChanged(sender As Object, e As EventArgs) Handles telepon.TextChanged

    End Sub

    Private Sub telepon_KeyPress(sender As Object, e As KeyPressEventArgs) Handles telepon.KeyPress
        If Char.IsNumber(e.KeyChar) OrElse e.KeyChar = vbBack Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
End Class