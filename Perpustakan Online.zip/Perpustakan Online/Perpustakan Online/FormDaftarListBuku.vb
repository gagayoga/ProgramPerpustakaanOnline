﻿Imports System.Data.SqlClient

Public Class FormDaftarListBuku
    Sub jumlahdata()
        Dim jmlh
        jmlh = DataGridView1.RowCount
        jumlah.Text = jmlh
    End Sub
    Sub Munculkandata()
        Call Koneksi()
        da = New SqlDataAdapter("SELECT * FROM buku", conn)
        ds = New DataSet
        da.Fill(ds, "buku")
        DataGridView1.DataSource = (ds.Tables("buku"))
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    Private Sub FormDaftarListBuku_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call jumlahdata()
        Call Munculkandata()
    End Sub
End Class