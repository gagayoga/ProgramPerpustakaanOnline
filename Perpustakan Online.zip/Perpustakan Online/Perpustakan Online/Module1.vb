﻿Imports System.Data.SqlClient

Module Module1
    Public conn As SqlConnection
    Public ds As DataSet
    Public da As SqlDataAdapter
    Public dr As SqlDataReader
    Public cmd As SqlCommand
    Public db As String

    Public Sub Koneksi()
        db = "data source=.; initial catalog=DB_Perpus; integrated security=True"
        conn = New SqlConnection(db)
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub
End Module
