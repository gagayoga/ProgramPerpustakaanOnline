﻿Imports System.Data.SqlClient

Public Class FormPengajuanBuku
    Sub Kondisiawal()
        'Ini deklarasi Untuk nilai awalan inputan
        id.Focus()
        id.Text = ""
        id.MaxLength = 11
        buku.Text = ""
        petugas.Text = ""
        anggota.Text = ""
        namaanggota.Text = ""
        namapetugas.Text = ""
        judulbuku.Text = ""
        pinjam.Text = ""
        kembali.Text = ""
        status.Text = ""
        'pinjam.ToString()
        'kembali.ToString()
        status.Text = "Pengajuan"
        Button1.Text = "INPUT"
        Button2.Text = "EDIT"
        Button3.Text = "DELETE"
        Button4.Text = "TUTUP"
        Munculkandata()
        'Call KodeOtomatis()
        'Call edittampilan()
        Call petukode()
        Call bukukode()
    End Sub
    Sub Munculkandata()
        Call Koneksi()
        da = New SqlDataAdapter("SELECT * FROM peminjaman", conn)
        ds = New DataSet
        da.Fill(ds, "peminjaman")
        DataGridView1.DataSource = (ds.Tables("peminjaman"))
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub
    Sub petukode()
        Call Koneksi()
        cmd = New SqlCommand("select * from petugas", conn)
        dr = cmd.ExecuteReader
        petugas.Items.Clear()
        Do While dr.Read()
            petugas.Items.Add(dr.Item(0))
        Loop

    End Sub
    Sub bukukode()
        Call Koneksi()
        cmd = New SqlCommand("select * from buku", conn)
        dr = cmd.ExecuteReader
        buku.Items.Clear()
        Do While dr.Read()
            buku.Items.Add(dr.Item(0))
        Loop

    End Sub
    Private Sub FormPengajuanBuku_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Kondisiawal()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If id.Text = "" Or buku.Text = "" Or anggota.Text = "" Or petugas.Text = "" Or pinjam.Text = "" Or kembali.Text = "" Or status.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            Call Koneksi()
            cmd = New SqlCommand("SELECT * FROM peminjaman where id_peminjaman='" & id.Text & "'", conn)
            dr = cmd.ExecuteReader()
            dr.Read()
            If dr.HasRows Then
                MsgBox("Data dengan id tersebut sudah ada,silakan masukan id yang lain", MessageBoxIcon.Information)
                id.Focus()
            Else
                'ini proses mencocokan data dengan inputan user
                Call Koneksi()
                Dim InputData = "INSERT INTO peminjaman values('" & id.Text & "','" & buku.Text & "','" & anggota.Text & "','" & petugas.Text & "','" & pinjam.Text & "','" & kembali.Text & "','" & status.Text & "')"
                cmd = New SqlCommand(InputData, conn)
                cmd.ExecuteReader()
                MsgBox("Data berhasil di input", MessageBoxIcon.Information)
                Call Kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If id.Text = "" Or buku.Text = "" Or anggota.Text = "" Or petugas.Text = "" Or pinjam.Text = "" Or kembali.Text = "" Or status.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            'ini proses mencocokan data dengan inputan user
            Call Koneksi()
            Dim EditData = "UPDATE peminjaman set kode_buku='" & buku.Text & "', id_anggota='" & anggota.Text & "',id_petugas='" & petugas.Text & "', tgl_pinjam='" & pinjam.Text & "' , tgl_kembali='" & kembali.Text & "',status='" & status.Text & "' where id_peminjaman='" & id.Text & "'"
            cmd = New SqlCommand(EditData, conn)
            cmd.ExecuteReader()
            MsgBox("Data berhasil di edit", MessageBoxIcon.Information)
            Call Kondisiawal()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If id.Text = "" Or buku.Text = "" Or anggota.Text = "" Or petugas.Text = "" Or pinjam.Text = "" Or kembali.Text = "" Or status.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            If MessageBox.Show("Apakah anda yakin mau menghapus data", "Pertanyaan", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Dim HapusData = "Delete from peminjaman where id_peminjaman='" & id.Text & "'"
                cmd = New SqlCommand(HapusData, conn)
                cmd.ExecuteReader()
                MsgBox("Data berhasil di edit", MessageBoxIcon.Information)
                Call Kondisiawal()
            Else
                Call Kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        On Error Resume Next
        id.Text = DataGridView1.Item(0, i).Value
        buku.Text = DataGridView1.Item(1, i).Value
        anggota.Text = DataGridView1.Item(2, i).Value
        petugas.Text = DataGridView1.Item(3, i).Value
        pinjam.Text = DataGridView1.Item(4, i).Value
        kembali.Text = DataGridView1.Item(5, i).Value
        status.Text = DataGridView1.Item(6, i).Value
    End Sub

    Private Sub buku_SelectedIndexChanged(sender As Object, e As EventArgs) Handles buku.SelectedIndexChanged
        Call Koneksi()
        cmd = New SqlCommand("select * from buku where kode_buku='" & buku.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            judulbuku.Text = dr.Item("judul")
        Else
            MsgBox("Data tidak ditemukan")
        End If
    End Sub

    Private Sub petugas_SelectedIndexChanged(sender As Object, e As EventArgs) Handles petugas.SelectedIndexChanged
        Call Koneksi()
        cmd = New SqlCommand("select * from petugas where id_petugas='" & petugas.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            namapetugas.Text = dr.Item("nama_petugas")
        Else
            MsgBox("Data tidak ditemukan")
        End If
    End Sub
End Class