﻿Imports System.Data.SqlClient

Public Class FormDataAnggota
    Sub Kondisiawal()
        'Ini deklarasi Untuk nilai awalan inputan
        id.Focus()
        id.Text = ""
        id.MaxLength = 6
        telepon.MaxLength = 13
        username.Text = ""
        nama.Text = ""
        telepon.Text = ""
        password.Text = ""
        password.ForeColor = Color.Black
        password.PasswordChar = "X"
        Button1.Text = "INPUT"
        Button2.Text = "EDIT"
        Button3.Text = "DELETE"
        Button4.Text = "TUTUP"
        'peringatan.Text = ""
        'peringatan.Enabled = False
        Munculkandata()
        'Call KodeOtomatis()
        'Call edittampilan()
    End Sub
    'Sub KodeOtomatis()
    '    Call Kondisiawal()
    '    cmd = New SqlCommand("select * from anggota where id_anggota in(select max(id_anggota) from anggota)", conn)
    '    Dim urutankode As Integer
    '    Dim hitung As Long
    '    dr = cmd.ExecuteReader
    '    dr.Read()
    '    If Not dr.HasRows Then
    '        id.Text = "000001"
    '    Else
    '        hitung = Microsoft.VisualBasic.Right(dr.GetString(0), 6) + 1
    '        urutankode = Microsoft.VisualBasic.Right("000000" & hitung, 6)
    '    End If
    '    id.Text = urutankode
    'End Sub
    Sub Munculkandata()
        Call Koneksi()
        da = New SqlDataAdapter("SELECT * FROM anggota2", conn)
        ds = New DataSet
        da.Fill(ds, "anggota2")
        DataGridView1.DataSource = (ds.Tables("anggota2"))
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    'Sub edittampilan()
    '    DataGridView1.Columns(0).HeaderText = "Id Anggota"
    '    DataGridView1.Columns(1).HeaderText = "Nama"
    '    DataGridView1.Columns(2).HeaderText = "Username"
    '    DataGridView1.Columns(3).HeaderText = "Password"
    '    DataGridView1.Columns(4).HeaderText = "Telepon"
    'End Sub
    Private Sub FormDataAnggota_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Kondisiawal()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If id.Text = "" Or nama.Text = "" Or username.Text = "" Or password.Text = "" Or telepon.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            Call Koneksi()
            cmd = New SqlCommand("SELECT * FROM anggota2 where id_anggota='" & id.Text & "'", conn)
            dr = cmd.ExecuteReader()
            dr.Read()
            If dr.HasRows Then
                MsgBox("Data dengan id tersebut sudah ada,silakan masukan id yang lain", MessageBoxIcon.Information)
                id.Focus()
            Else
                'ini proses mencocokan data dengan inputan user
                Call Koneksi()
                Dim InputData = "INSERT INTO anggota2 values('" & id.Text & "','" & nama.Text & "','" & username.Text & "','" & password.Text & "','" & telepon.Text & "')"
                cmd = New SqlCommand(InputData, conn)
                cmd.ExecuteReader()
                MsgBox("Data berhasil di input", MessageBoxIcon.Information)
                Call Kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If id.Text = "" Or nama.Text = "" Or username.Text = "" Or password.Text = "" Or telepon.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            'ini proses mencocokan data dengan inputan user
            Call Koneksi()
            Dim EditData = "UPDATE anggota2 set nama='" & nama.Text & "', username='" & username.Text & "',pasword='" & password.Text & "', telp='" & telepon.Text & "' where id_anggota='" & id.Text & "'"
            cmd = New SqlCommand(EditData, conn)
            cmd.ExecuteReader()
            MsgBox("Data berhasil di edit", MessageBoxIcon.Information)
            Call Kondisiawal()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If id.Text = "" Or nama.Text = "" Or username.Text = "" Or password.Text = "" Or telepon.Text = "" Then
            MsgBox("Silakan isi semua datanya terlebih dahulu", MessageBoxIcon.Information)
        Else
            If MessageBox.Show("Apakah anda yakin mau menghapus data", "Pertanyaan", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Dim HapusData = "Delete from anggota2 where id_anggota='" & id.Text & "'"
                cmd = New SqlCommand(HapusData, conn)
                cmd.ExecuteReader()
                MsgBox("Data berhasil di edit", MessageBoxIcon.Information)
                Call Kondisiawal()
            Else
                Call Kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        On Error Resume Next
        id.Text = DataGridView1.Item(0, i).Value
        nama.Text = DataGridView1.Item(1, i).Value
        username.Text = DataGridView1.Item(2, i).Value
        password.Text = DataGridView1.Item(3, i).Value
        telepon.Text = DataGridView1.Item(4, i).Value
    End Sub

    Private Sub id_TextChanged(sender As Object, e As EventArgs) Handles id.TextChanged

    End Sub

    Private Sub id_KeyPress(sender As Object, e As KeyPressEventArgs) Handles id.KeyPress
        If Char.IsNumber(e.KeyChar) OrElse e.KeyChar = vbBack Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub telepon_TextChanged(sender As Object, e As EventArgs) Handles telepon.TextChanged

    End Sub

    Private Sub telepon_KeyPress(sender As Object, e As KeyPressEventArgs) Handles telepon.KeyPress
        If Char.IsNumber(e.KeyChar) OrElse e.KeyChar = vbBack Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
End Class