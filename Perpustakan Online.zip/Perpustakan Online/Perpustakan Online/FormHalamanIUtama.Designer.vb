﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormHalamanIUtama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.KeluarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DaftarListBukuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataPengajuanBukuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DaftarListPengajuanBukuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataPetugasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataAnggotaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataBukuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransaksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataPeminjamanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataBukuToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataPeminjamanToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditProfilAnggotaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditProfilPetugasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.SLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabelisi1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabelisi2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabelisi3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabelisi4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SLabelisi5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.MenuToolStripMenuItem, Me.MasterToolStripMenuItem, Me.TransaksiToolStripMenuItem, Me.LaporanToolStripMenuItem, Me.UtilityToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogoutToolStripMenuItem, Me.ToolStripMenuItem1, Me.KeluarToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(177, 6)
        '
        'KeluarToolStripMenuItem
        '
        Me.KeluarToolStripMenuItem.Name = "KeluarToolStripMenuItem"
        Me.KeluarToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.KeluarToolStripMenuItem.Text = "Keluar"
        '
        'MenuToolStripMenuItem
        '
        Me.MenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DaftarListBukuToolStripMenuItem, Me.DataPengajuanBukuToolStripMenuItem, Me.DaftarListPengajuanBukuToolStripMenuItem})
        Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.MenuToolStripMenuItem.Text = "Menu"
        '
        'DaftarListBukuToolStripMenuItem
        '
        Me.DaftarListBukuToolStripMenuItem.Name = "DaftarListBukuToolStripMenuItem"
        Me.DaftarListBukuToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.DaftarListBukuToolStripMenuItem.Text = "Daftar List Buku"
        '
        'DataPengajuanBukuToolStripMenuItem
        '
        Me.DataPengajuanBukuToolStripMenuItem.Name = "DataPengajuanBukuToolStripMenuItem"
        Me.DataPengajuanBukuToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.DataPengajuanBukuToolStripMenuItem.Text = "Data Pengajuan Buku"
        '
        'DaftarListPengajuanBukuToolStripMenuItem
        '
        Me.DaftarListPengajuanBukuToolStripMenuItem.Name = "DaftarListPengajuanBukuToolStripMenuItem"
        Me.DaftarListPengajuanBukuToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.DaftarListPengajuanBukuToolStripMenuItem.Text = "Daftar List Pengajuan Buku"
        '
        'MasterToolStripMenuItem
        '
        Me.MasterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataPetugasToolStripMenuItem, Me.DataAnggotaToolStripMenuItem, Me.DataBukuToolStripMenuItem})
        Me.MasterToolStripMenuItem.Name = "MasterToolStripMenuItem"
        Me.MasterToolStripMenuItem.Size = New System.Drawing.Size(55, 20)
        Me.MasterToolStripMenuItem.Text = "Master"
        '
        'DataPetugasToolStripMenuItem
        '
        Me.DataPetugasToolStripMenuItem.Name = "DataPetugasToolStripMenuItem"
        Me.DataPetugasToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DataPetugasToolStripMenuItem.Text = "Data Petugas"
        '
        'DataAnggotaToolStripMenuItem
        '
        Me.DataAnggotaToolStripMenuItem.Name = "DataAnggotaToolStripMenuItem"
        Me.DataAnggotaToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DataAnggotaToolStripMenuItem.Text = "Data Anggota"
        '
        'DataBukuToolStripMenuItem
        '
        Me.DataBukuToolStripMenuItem.Name = "DataBukuToolStripMenuItem"
        Me.DataBukuToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DataBukuToolStripMenuItem.Text = "Data Buku"
        '
        'TransaksiToolStripMenuItem
        '
        Me.TransaksiToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataPeminjamanToolStripMenuItem})
        Me.TransaksiToolStripMenuItem.Name = "TransaksiToolStripMenuItem"
        Me.TransaksiToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.TransaksiToolStripMenuItem.Text = "Transaksi"
        '
        'DataPeminjamanToolStripMenuItem
        '
        Me.DataPeminjamanToolStripMenuItem.Name = "DataPeminjamanToolStripMenuItem"
        Me.DataPeminjamanToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DataPeminjamanToolStripMenuItem.Text = "Data Peminjaman"
        '
        'LaporanToolStripMenuItem
        '
        Me.LaporanToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataBukuToolStripMenuItem1, Me.DataPeminjamanToolStripMenuItem1})
        Me.LaporanToolStripMenuItem.Name = "LaporanToolStripMenuItem"
        Me.LaporanToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.LaporanToolStripMenuItem.Text = "Laporan"
        '
        'DataBukuToolStripMenuItem1
        '
        Me.DataBukuToolStripMenuItem1.Name = "DataBukuToolStripMenuItem1"
        Me.DataBukuToolStripMenuItem1.Size = New System.Drawing.Size(214, 22)
        Me.DataBukuToolStripMenuItem1.Text = "Laporan Data Buku"
        '
        'DataPeminjamanToolStripMenuItem1
        '
        Me.DataPeminjamanToolStripMenuItem1.Name = "DataPeminjamanToolStripMenuItem1"
        Me.DataPeminjamanToolStripMenuItem1.Size = New System.Drawing.Size(214, 22)
        Me.DataPeminjamanToolStripMenuItem1.Text = "Laporan Data Peminjaman"
        '
        'UtilityToolStripMenuItem
        '
        Me.UtilityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditProfilAnggotaToolStripMenuItem, Me.EditProfilPetugasToolStripMenuItem})
        Me.UtilityToolStripMenuItem.Name = "UtilityToolStripMenuItem"
        Me.UtilityToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.UtilityToolStripMenuItem.Text = "Utility"
        '
        'EditProfilAnggotaToolStripMenuItem
        '
        Me.EditProfilAnggotaToolStripMenuItem.Name = "EditProfilAnggotaToolStripMenuItem"
        Me.EditProfilAnggotaToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.EditProfilAnggotaToolStripMenuItem.Text = "Edit Profil Anggota"
        '
        'EditProfilPetugasToolStripMenuItem
        '
        Me.EditProfilPetugasToolStripMenuItem.Name = "EditProfilPetugasToolStripMenuItem"
        Me.EditProfilPetugasToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.EditProfilPetugasToolStripMenuItem.Text = "Edit Profil Petugas"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SLabel1, Me.SLabelisi1, Me.SLabel2, Me.SLabelisi2, Me.SLabel3, Me.SLabelisi3, Me.SLabel4, Me.SLabelisi4, Me.SLabel5, Me.SLabelisi5})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 428)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(800, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'SLabel1
        '
        Me.SLabel1.Name = "SLabel1"
        Me.SLabel1.Size = New System.Drawing.Size(69, 17)
        Me.SLabel1.Text = "Username : "
        '
        'SLabelisi1
        '
        Me.SLabelisi1.Name = "SLabelisi1"
        Me.SLabelisi1.Size = New System.Drawing.Size(0, 17)
        '
        'SLabel2
        '
        Me.SLabel2.Name = "SLabel2"
        Me.SLabel2.Size = New System.Drawing.Size(72, 17)
        Me.SLabel2.Text = "Id Anggota :"
        '
        'SLabelisi2
        '
        Me.SLabelisi2.Name = "SLabelisi2"
        Me.SLabelisi2.Size = New System.Drawing.Size(0, 17)
        '
        'SLabel3
        '
        Me.SLabel3.Name = "SLabel3"
        Me.SLabel3.Size = New System.Drawing.Size(43, 17)
        Me.SLabel3.Text = "Level : "
        '
        'SLabelisi3
        '
        Me.SLabelisi3.Name = "SLabelisi3"
        Me.SLabelisi3.Size = New System.Drawing.Size(0, 17)
        '
        'SLabel4
        '
        Me.SLabel4.Name = "SLabel4"
        Me.SLabel4.Size = New System.Drawing.Size(57, 17)
        Me.SLabel4.Text = "Tanggal : "
        '
        'SLabelisi4
        '
        Me.SLabelisi4.Name = "SLabelisi4"
        Me.SLabelisi4.Size = New System.Drawing.Size(0, 17)
        '
        'SLabel5
        '
        Me.SLabel5.Name = "SLabel5"
        Me.SLabel5.Size = New System.Drawing.Size(37, 17)
        Me.SLabel5.Text = "Jam : "
        '
        'SLabelisi5
        '
        Me.SLabelisi5.Name = "SLabelisi5"
        Me.SLabelisi5.Size = New System.Drawing.Size(0, 17)
        '
        'Timer1
        '
        '
        'FormHalamanIUtama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormHalamanIUtama"
        Me.ShowInTaskbar = False
        Me.Text = "FormHalamanIUtama"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripSeparator
    Friend WithEvents KeluarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DaftarListBukuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataPengajuanBukuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DaftarListPengajuanBukuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MasterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataPetugasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataAnggotaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataBukuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransaksiToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataPeminjamanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UtilityToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditProfilAnggotaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditProfilPetugasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LaporanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataBukuToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents DataPeminjamanToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents SLabel1 As ToolStripStatusLabel
    Friend WithEvents SLabelisi1 As ToolStripStatusLabel
    Friend WithEvents SLabel2 As ToolStripStatusLabel
    Friend WithEvents SLabelisi2 As ToolStripStatusLabel
    Friend WithEvents SLabel3 As ToolStripStatusLabel
    Friend WithEvents SLabelisi3 As ToolStripStatusLabel
    Friend WithEvents SLabel4 As ToolStripStatusLabel
    Friend WithEvents SLabelisi4 As ToolStripStatusLabel
    Friend WithEvents SLabel5 As ToolStripStatusLabel
    Friend WithEvents SLabelisi5 As ToolStripStatusLabel
    Friend WithEvents Timer1 As Timer
End Class
