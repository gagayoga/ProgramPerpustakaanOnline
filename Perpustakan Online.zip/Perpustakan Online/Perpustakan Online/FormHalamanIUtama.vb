﻿Public Class FormHalamanIUtama
    Private Sub DataBukuToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles DataBukuToolStripMenuItem1.Click
        FormLaporanDataBuku.ShowDialog()
    End Sub

    Private Sub MenuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MenuToolStripMenuItem.Click

    End Sub

    Private Sub DaftarListBukuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DaftarListBukuToolStripMenuItem.Click
        FormDaftarListBuku.ShowDialog()
    End Sub

    Private Sub DataPengajuanBukuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DataPengajuanBukuToolStripMenuItem.Click
        FormPengajuanBuku.ShowDialog()
    End Sub

    Private Sub DaftarListPengajuanBukuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DaftarListPengajuanBukuToolStripMenuItem.Click
        FormDatalistBukuPengajuan.ShowDialog()
    End Sub

    Private Sub DataPetugasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DataPetugasToolStripMenuItem.Click
        FormDataPetugas.ShowDialog()
    End Sub

    Private Sub DataAnggotaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DataAnggotaToolStripMenuItem.Click
        FormDataAnggota.ShowDialog()
    End Sub

    Private Sub DataBukuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DataBukuToolStripMenuItem.Click
        FormDataBuku.ShowDialog()
    End Sub

    Private Sub DataPeminjamanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DataPeminjamanToolStripMenuItem.Click
        FormDataPeminjaman.ShowDialog()
    End Sub

    Private Sub DataPeminjamanToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles DataPeminjamanToolStripMenuItem1.Click
        FormLaporanDataPeminjaman.ShowDialog()
    End Sub

    Private Sub EditProfilAnggotaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditProfilAnggotaToolStripMenuItem.Click
        FormEditAnggota.ShowDialog()
    End Sub

    Private Sub EditProfilPetugasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditProfilPetugasToolStripMenuItem.Click
        FormEditPetugas.ShowDialog()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        SLabelisi5.Text = TimeOfDay
    End Sub

    Private Sub FormHalamanIUtama_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SLabelisi4.Text = Today
    End Sub
End Class