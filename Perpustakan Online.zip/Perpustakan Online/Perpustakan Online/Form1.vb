﻿Imports System.Data.SqlClient

Public Class Form1
    Sub Kondisiawal()
        'Ini deklarasi Untuk nilai awalan inputan
        username.Text = "yogaairgi"
        password.Text = "yogairgi123"
        password.ForeColor = Color.Black
        password.PasswordChar = "X"
        peringatan.Text = ""
        peringatan.Enabled = False
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Kondisiawal()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            password.PasswordChar = ""
        Else
            password.PasswordChar = "X"
        End If
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        FormRegisterAnggota.ShowDialog()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'ini validasi jika ada inputan yang kosong maka akan muncul pop up
        If username.Text = "" Or password.Text = "" Then
            MsgBox("Masukan semua data terlebih dahulu", MessageBoxIcon.Warning)
            'ini validasi jika password kurang dari 8 maka teks akan berubah warna menjadi merah
            'ElseIf password.TextLength < 8 Then
            '    password.ForeColor = Color.Red
            '    peringatan.Text = "password minimal 8,kurang dari 8 tidak bisa masuk aplikasi"
        Else
            'ini proses mencocokan data dengan inputan user
            Call Koneksi()
            cmd = New SqlCommand("SELECT * FROM anggota2 where username='" & username.Text & "' and pasword='" & password.Text & "'", conn)
            dr = cmd.ExecuteReader()
            dr.Read()
            If dr.HasRows Then
                MsgBox("Login Berhasil", MessageBoxIcon.Information)
                Me.Hide()
                'ini untuk mengisi status strip di halaman utama
                FormHalamanIUtama.SLabelisi1.Text = dr.Item("username")
                FormHalamanIUtama.SLabelisi2.Text = dr.Item("id_anggota")
                FormHalamanIUtama.SLabel2.Text = "Id Anggota :"
                FormHalamanIUtama.SLabelisi3.Text = "Anggota"
                'ini validasi hak akses aplikasi 
                FormHalamanIUtama.DaftarListPengajuanBukuToolStripMenuItem.Visible = False
                FormHalamanIUtama.TransaksiToolStripMenuItem.Visible = False
                FormHalamanIUtama.LaporanToolStripMenuItem.Visible = False
                FormHalamanIUtama.EditProfilPetugasToolStripMenuItem.Visible = False
                FormHalamanIUtama.ShowDialog()
            Else
                MsgBox("Data tidak ditemukan,silakan anda login lagi dengan data yang benar", MessageBoxIcon.Information)
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        FormLoginPetugas.ShowDialog()
    End Sub
End Class
